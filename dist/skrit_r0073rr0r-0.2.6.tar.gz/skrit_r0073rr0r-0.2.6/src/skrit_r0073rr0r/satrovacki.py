"""Python Skrit Satrovacki"""
from skrit_r0073rr0r.skrit import Skrit

class Satrovacki(Skrit):
    """Python Skrit Satrovacki INIT"""
    def __init__(self):
        super().__init__()
        print('Satrovacki')
