"""Python Skrit Utrovacki"""
from skrit_r0073rr0r.skrit import Skrit

class Utrovacki(Skrit):
    """Python Skrit Utrovacki INIT"""
    def __init__(self):
        super().__init__()
        print('Utrovacki')
