# PSkrit

### Debug

```
from Skrit_r0073rr0r import skrit
print(skrit('rucka'))
```

***Output***:

``
ckarucka
 ``