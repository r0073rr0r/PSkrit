# PSkrit

### Debug
```
import skrit
print(Skrit('rucka'))
```

***Output***:

``
ckarucka
 ``