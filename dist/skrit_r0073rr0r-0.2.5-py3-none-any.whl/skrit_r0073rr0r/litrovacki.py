"""Python Skrit Litrovacki"""
from skrit_r0073rr0r.skrit import Skrit

class Litrovacki(Skrit):
    """Python Skrit Satrovacki INIT"""
    def __init__(self):
        super().__init__()
        print('Litrovacki')
